---
name: New topology request
about: Request support for a new converter topology
title: 'Add support for: [topology name]'
labels: enhancement, new-topology
---

## Topology

Name (e.g. SEPIC, Ćuk, Flyback, ...):

## Reference equations

Link or attach the small-signal model / averaged-model derivation you'd want this to match.

## Parameter list

List the parameters you'd expect the form to ask for.

## MATLAB reference

If you have a working MATLAB or Simulink reference, attach it. This becomes the test fixture under `tests/`.
